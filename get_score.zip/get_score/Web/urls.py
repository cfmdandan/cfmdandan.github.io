from django.urls import path
from .views import score_list, add_score

urlpatterns = [
    path('', score_list, name='score_list'),
    path('add/', add_score, name='add_score'),
]