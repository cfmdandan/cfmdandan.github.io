from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from .models import Score
from .forms import ScoreForm

def score_list(request):
    scores = Score.objects.all()
    return render(request, 'scores/score_list.html', {'scores': scores})

def add_score(request):
    if request.method == 'POST':
        form = ScoreForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('score_list')
    else:
        form = ScoreForm()
    return render(request, 'scores/add_score.html', {'form': form})